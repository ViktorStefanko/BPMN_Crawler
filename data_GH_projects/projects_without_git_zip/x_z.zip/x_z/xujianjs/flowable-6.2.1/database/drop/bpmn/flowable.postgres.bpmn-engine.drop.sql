drop table if exists ACT_RE_DEPLOYMENT cascade;
drop table if exists ACT_RE_MODEL cascade;
drop table if exists ACT_RE_PROCDEF cascade;
drop table if exists ACT_RU_EXECUTION cascade;
drop table if exists ACT_RU_EVENT_SUBSCR cascade;
drop table if exists ACT_EVT_LOG cascade;
drop table if exists ACT_PROCDEF_INFO cascade;
drop table if exists ACT_RU_JOB cascade;
drop table if exists ACT_RU_TIMER_JOB cascade;
drop table if exists ACT_RU_SUSPENDED_JOB cascade;
drop table if exists ACT_RU_DEADLETTER_JOB cascade;
drop table if exists ACT_RU_HISTORY_JOB cascade;
drop table if exists ACT_RU_VARIABLE cascade;

drop table if exists ACT_RU_TASK cascade;
drop table if exists ACT_RU_IDENTITYLINK cascade;
drop table if exists ACT_GE_BYTEARRAY cascade;
drop table if exists ACT_GE_PROPERTY cascade;

