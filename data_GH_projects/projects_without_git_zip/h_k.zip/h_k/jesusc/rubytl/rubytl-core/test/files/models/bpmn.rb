activity1 = Bpmn::Activity.new

activity2 = Bpmn::Activity.new