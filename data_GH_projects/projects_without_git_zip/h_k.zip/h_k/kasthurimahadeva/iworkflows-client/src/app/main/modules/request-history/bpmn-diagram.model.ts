export class BpmnDiagramModel {
    xml: string;
    taskDefinitionKey: string;
}
