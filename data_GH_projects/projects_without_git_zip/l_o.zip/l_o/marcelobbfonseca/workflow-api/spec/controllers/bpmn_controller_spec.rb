require 'rails_helper'

RSpec.describe BpmnController, type: :controller do

end
