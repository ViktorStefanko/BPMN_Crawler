### [**🏠 Home**](/README.md)

###  [**⬅️ Back**](choreographies/roles.md)
-----
# BPMN [(sources)](https://github.com/loopingdoge/acme-agency/blob/master/bpmn)

Il BPMN è composto da una pool eseguibile per l'agenzia ACME, una pool per ogni client (acquirente e venditore) ed una per ciascuno dei servizi esterni (Catasto, Distanza, Banca)

------
### [**➡️ Next**](external-services.md)