var componentId = '${componentId}',
    xmlComponentId = '${xmlComponentId}',
    locale = '${lang}';

installBpmnModeler(componentId, xmlComponentId, locale);