var xml = ${xml};
var componentId = '${componentId}';
installBpmnViewer(componentId, xml);