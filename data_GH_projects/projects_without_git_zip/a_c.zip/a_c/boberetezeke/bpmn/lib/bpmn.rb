require "rgl-fold"
require "nokogiri"

require "bpmn/xml_parser"
require "bpmn/name_parser"
require "bpmn/node_attributes"
